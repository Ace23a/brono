const {
  Client,
  GatewayIntentBits,
  PermissionsBitField,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType
} = require("discord.js");
const config = require("./config.json");
const { joinVoiceChannel } = require("@discordjs/voice");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent
  ]
});

/* ================= VOICE CHANNEL STAY ================= */
client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);

  const guild = client.guilds.cache.get(config.guildId);
  if (!guild) return console.log("❌ Guild not found");

  const channel = guild.channels.cache.get(config.voiceChannelId);
  if (!channel) return console.log("❌ Voice channel not found");

  joinVoiceChannel({
    channelId: channel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
    selfMute: false
  });

  console.log("🎧 Bot joined the voice channel and will stay there");
});

/* ================= TICKET SYSTEM ================= */
client.on("interactionCreate", async interaction => {

  // Select Menu for Ticket
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId === 'ticket-menu') {

      const selectedValue = interaction.values[0];
      const user = interaction.user;
      const guild = interaction.guild;

      let categoryId;
      let channelName;

      if (selectedValue === 'order_ticket') {
        categoryId = config.order_category_id;
        channelName = `order-${user.username}`;
      } else if (selectedValue === 'support_ticket') {
        categoryId = config.support_category_id;
        channelName = `support-${user.username}`;
      }

      if (!categoryId) return interaction.reply({ content: "❌ Ticket category not configured. Please contact an admin.", ephemeral: true });

      const category = guild.channels.cache.get(categoryId);
      if (!category || category.type !== ChannelType.GuildCategory) return interaction.reply({ content: "❌ Invalid ticket category ID. Please contact an admin.", ephemeral: true });

      const existingChannel = guild.channels.cache.find(c => c.name === channelName && c.parentId === categoryId);
      if (existingChannel) return interaction.reply({ content: `** You already have an open ticket: <#${existingChannel.id}>**`, ephemeral: true });

      const newChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: category,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
          { id: config.adminRole, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
        ],
      });

      const embed = new EmbedBuilder()
        .setTitle(`** Welcome to your Ticket!**`)
        .setDescription(`**Hello ${user}, thank you for creating a ticket. \nPlease describe your request, and a staff member will be with you shortly <@&1470538186072653967>**`)
        .setColor("#2b2d31")
        .setTimestamp();

      const deleteButton = new ButtonBuilder()
        .setCustomId('delete_ticket')
        .setLabel('Close')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('<:delete:1470476515941552190>');

      const row = new ActionRowBuilder().addComponents(deleteButton);

      await newChannel.send({ content: `${user}`, embeds: [embed], components: [row] });
      await interaction.reply({ content: `**Your ticket has been created: <#${newChannel.id}>**`, ephemeral: true });
    }

  } else if (interaction.isButton()) {
    // Delete Ticket Button
    if (interaction.customId === 'delete_ticket') {
      await interaction.reply({ content: '** Deleting this channel in 5 seconds...**', ephemeral: true });
      setTimeout(() => interaction.channel.delete(), 5000);
    }
  }
});

/* ================= PREFIX COMMAND +tickets ================= */
client.on("messageCreate", async message => {
  if (message.author.bot) return;
  if (!message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const cmd = args.shift().toLowerCase();

  if (cmd === "tickets") {
    const embed = new EmbedBuilder()
      .setTitle("**Create a New Ticket**")
      .setDescription("**Please select a category from the menu below to open a ticket.**")
      .setColor("#2b2d31");

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket-menu')
      .setPlaceholder('Nothing selected')
      .addOptions([
        { label: 'Order Ticket', description: 'Create a ticket for a new order.', value: 'order_ticket', emoji: '<a:emoji_17:1469264417492566070>' },
        { label: 'Support Ticket', description: 'Create a ticket for technical support.', value: 'support_ticket', emoji: '<:emoji_16:1469264411909947585>' },
      ]);

    const row = new ActionRowBuilder().addComponents(selectMenu);
    message.channel.send({ embeds: [embed], components: [row] });
  }
});

client.login(config.token);
